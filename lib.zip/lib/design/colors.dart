import 'package:flutter/material.dart';

Color primaryColor = const Color(0xFFF896D8); //rosa
Color secondaryColor = const Color(0xFFCA7DF9); //morado
Color tertiaryColor = const Color(0xFF724CF9); //lila
