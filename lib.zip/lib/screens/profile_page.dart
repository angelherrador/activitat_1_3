import 'package:flutter/material.dart';
import '../models/activities.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {

  double sliderValueHeight = 180;
  double sliderValueWeight = 70;

  @override
  Widget build(BuildContext context) {

    var imageWidth =
        MediaQuery.of(context).size.width * 0.60; //80% del ancho de pantalla

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
          ),
        ),
        title: const Text(
          'My Profile',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),

      body: SingleChildScrollView(
        child: Center(
          child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Hero(
              tag: '1',
              child: Container(
                  margin: const EdgeInsets.only(top:8),
                  width: imageWidth,
                  height: imageWidth,
                  decoration:  const BoxDecoration(
                      shape: BoxShape.circle,
                      image:  DecorationImage(
                          fit: BoxFit.fill,
                          image:  NetworkImage(imageProfile)
                      )
                  )
              ),),
            const SizedBox(height: 10),
            Text('Antònia Font', style: Theme.of(context).textTheme.displayMedium,),
            const SizedBox(height: 5),
            Text('since 20 April 2022', style: Theme.of(context).textTheme.titleMedium,),
            const SizedBox(height: 40),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    Icon(Icons.access_time),
                    Text('Time'),
                    Text("2h 45'"),
                    ],

                ),
                Column(
                  children: [
                    Icon(Icons.room_outlined),
                    Text("Km"),
                    Text("212,4"),
                  ],
                ),
                Column(
                  children: [
                    Icon(Icons.directions_run),
                    Text("Activities"),
                    Text('42'),
                  ],
                )
              ],
            ),

            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Slider(
                  value: sliderValueHeight,
                  max: 220,
                  label: sliderValueHeight.round().toString(),
                  onChanged: (double value) {
                    setState(() => sliderValueHeight= value);
                }),
                Text('${sliderValueHeight.round()} cm'),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Slider(
                    value: sliderValueWeight,
                    max: 300,
                    label: sliderValueWeight.round().toString(),
                    onChanged: (double value) {
                      setState(() {
                        sliderValueWeight= value;
                      });
                    }),
                Text('${sliderValueWeight.round()} Kg'),
              ],
            ),
          ]
        ),
      ),
    ),
    );


  }
}
